# Zabbix map icons — Halloween edition

This is a seasonal version of the flat icon set: night purple, pumpkin orange, bone and slime green, with Halloween details.

| Icon | Halloween version |
|---|---|
| Cloud | Spooky cloud with glowing eyes and bats |
| House | Haunted house with lit windows, a moon, a bat and a cobweb |
| Firewall | Purple stone wall with green flames and a skull |
| Server | Tower with a glowing jack-o'-lantern face |
| UPS | Coffin with a slime-green battery gauge |
| Router symbol | Pumpkin cylinder with arrows in two separate rows |
| Racks | Cobwebs and a spider; a ghost peeks out from behind the door |
| Notebook, workstation, network | Jack-o'-lantern screens |
| Video terminal | Ghost, pumpkin, skull and bat call tiles |
| Hub, switch, router, modem, phone, printer, PBX, network adapter, satellites | Bats, cobwebs, spiders, a skull chip, a bat print and a moon |
| Rack-mountable servers, disk array, UPS rack unit, Zabbix server | Purple with slime-green LEDs and an orange Zabbix badge |

**Drop-in replacement:** file names, pixel sizes and image IDs are identical to the built-in map icons (Zabbix 8.0.0rc3), so existing maps keep working.

**Small sizes:** at 32 px and below, the decorations are left out so the devices stay readable.

**Arrows:** `tools/check_arrows.py` checks that no two arrows touch in any size. The current result is 14 icon sizes checked, 0 problems.

## Swap in for Halloween, and back afterwards

```
# install, keeping a backup of the current icons
tools/zabbix_import_map_icons.py --url https://zabbix.example.com --token "$ZABBIX_TOKEN" \
    --source zabbix_halloween_map_icons.zip --backup ./icons_before_halloween --skip-version-check

# after Halloween: restore the previous icons
tools/zabbix_import_map_icons.py --url https://zabbix.example.com --token "$ZABBIX_TOKEN" \
    --source ./icons_before_halloween --no-create --skip-version-check
```

You can also use `database/<db>/update_images.sql`. Back up the `images` table first.

## Contents

| Path | What |
|---|---|
| `svg/` | Vector sources |
| `png_modern/` | 187 PNGs |
| `png_classic/` | 20 PNGs |
| `database/*/images.sql`<br>`database/*/update_images.sql` | SQL for new installs and for existing installs |
| `preview_*.png` | Preview sheets |
| `tools/` | Generator (`icons_base.py`, `icons_halloween.py`, `render.py`, `gen_sql.py`), arrow check, and import script |
