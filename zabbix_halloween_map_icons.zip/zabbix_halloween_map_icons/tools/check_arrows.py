"""Check that no two arrows touch in any rendered size (router symbols use arrows)."""
import glob, os, re, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import icons_halloween as I
ORIG = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'orig')
bad = n = 0
for p in sorted(glob.glob(os.path.join(ORIG, '*.png'))):
    fn = os.path.basename(p)[:-4]
    base = re.match(r'(.+)_\(\d+\)$', fn).group(1)
    w, h = Image.open(p).size
    gap, cnt = I.check_arrows(base, max(w, h) <= 32)
    if cnt < 2:
        continue
    vw = float(re.search(r'viewBox="0 0 ([\d.]+)', I.icon_svg(base, max(w, h) <= 32)).group(1))
    px = gap * w / vw
    ok = px >= 1.5
    n += 1; bad += not ok
    print('%-30s arrows=%d  gap %.1f units / %.1f px  %s' % (fn, cnt, gap, px, 'OK' if ok else 'TOO CLOSE'))
print('%d icon sizes with arrows checked, %d problems' % (n, bad))
sys.exit(1 if bad else 0)
