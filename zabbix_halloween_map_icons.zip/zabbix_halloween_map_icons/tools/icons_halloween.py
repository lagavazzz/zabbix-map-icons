"""Halloween edition of the flat Zabbix map icon set.

Builds on the flat set (icons_base.py): the palette is swapped for a Halloween
one (night purple, pumpkin orange, bone, slime green) and the devices get
seasonal details: jack-o'-lantern screens, bats, cobwebs, a haunted house,
a coffin UPS, a pumpkin router symbol, green flames on the firewall, a ghost
peeking out of the rack.

Names, aspect ratios and pixel sizes are identical to the built-in set, so the
PNGs replace the default icons one for one.
"""
import math
import icons_base as B
from icons_base import f, R, Cc, E, P, G, L, PL, T

# ------------------------------------------------------------------ palette swap
B.C.update(
    red='#B5121B', red_d='#7E0C12', red_l='#E5383B',
    blue='#F57C1F', blue_d='#C9560D', blue_l='#FFA040', blue_xl='#FFD08A', blue_xxl='#FFE8C7',
    ink='#1A1024', slate_d='#271838', slate='#3B2650', slate_m='#4E3468', slate_l='#6B4C8A', slate_xl='#9A84B5',
    g1='#F6F1E7', g2='#E9E0CF', g3='#D3C6AE', g4='#B5A68C', g5='#968770',
    green='#8EE53F', green_l='#C6FF7A', amber='#FFB627', amber_l='#FFE066', white='#FFFFFF',
    pcb='#3D2A55', pcb_d='#2A1C3D', gold='#E2B045', gold_d='#B98A24',
)
C = B.C
H = dict(night='#22133A', night2='#2E1A4A', glow='#FFB627', glow_l='#FFE066', pumpkin='#F57C1F',
         pumpkin_d='#D2600E', pumpkin_l='#FF9A3C', stem='#5E7A2A', bone='#F6F1E7', web='#D8CDE9',
         slime='#8EE53F', slime_l='#C6FF7A', moon='#FFE7A3', wood='#4A2E3E', wood_l='#6A4458', bat='#1A1024')
ARROWS = []  # arrow polygons (shapely-ready point lists, icon coordinates) for the spacing check
_XF = [(1.0, 0.0, 0.0)]


def lo():
    return B.LO


# ------------------------------------------------------------------ Halloween parts
def jack_face(cx, cy, w, col=None):
    col = col or H['glow']
    u = lambda a, b: (cx + a * w, cy + b * w)
    s = G([u(-0.34, -0.02), u(-0.1, -0.02), u(-0.22, -0.26)], col)
    s += G([u(0.34, -0.02), u(0.1, -0.02), u(0.22, -0.26)], col)
    if w >= 14 or not lo():
        s += G([u(-0.06, 0.08), u(0.06, 0.08), u(0, -0.02)], col)
    s += G([u(-0.4, 0.14), u(-0.24, 0.2), u(-0.18, 0.14), u(-0.08, 0.21), u(0.08, 0.21), u(0.18, 0.14),
            u(0.24, 0.2), u(0.4, 0.14), u(0.3, 0.32), u(0.12, 0.39), u(0.06, 0.32), u(-0.06, 0.32), u(-0.12, 0.39),
            u(-0.3, 0.32)], col)
    return s


def pumpkin(cx, cy, w, face=True):
    h = w * 0.82
    s = R(cx - w * 0.05, cy - h * 0.62, w * 0.1, h * 0.22, H['stem'], w * 0.03)
    s += E(cx - w * 0.24, cy, w * 0.28, h / 2, H['pumpkin_d'])
    s += E(cx + w * 0.24, cy, w * 0.28, h / 2, H['pumpkin_d'])
    s += E(cx, cy, w * 0.3, h / 2, H['pumpkin'])
    if face:
        s += jack_face(cx, cy + h * 0.02, w * 0.62, H['night'])
    return s


def bat(cx, cy, w, col=None):
    col = col or H['bat']
    pts = [(0.05, -0.04), (0.18, -0.2), (0.3, -0.22), (0.5, -0.04), (0.42, -0.03), (0.36, 0.07), (0.28, 0.0),
           (0.2, 0.09), (0.12, 0.0), (0.05, 0.06)]
    right = [(cx + a * w, cy + b * w) for a, b in pts]
    left = [(cx - a * w, cy + b * w) for a, b in reversed(pts)]
    s = G(right + left, col)
    s += E(cx, cy + w * 0.01, w * 0.07, w * 0.11, col)
    s += G([(cx - w * 0.06, cy - w * 0.06), (cx - w * 0.04, cy - w * 0.15), (cx - w * 0.01, cy - w * 0.08),
            (cx + w * 0.01, cy - w * 0.08), (cx + w * 0.04, cy - w * 0.15), (cx + w * 0.06, cy - w * 0.06)], col)
    return s


def web(x, y, r, quad=0, col=None):
    """Corner cobweb anchored at (x, y); quad 0=down-right, 1=down-left, 2=up-left, 3=up-right."""
    col = col or H['web']
    base = [0, 90, 180, 270][quad]
    angs = [math.radians(base + a) for a in (0, 22.5, 45, 67.5, 90)]
    sw = max(0.6, r * 0.035)
    s = ''
    for a in angs:
        s += L(x, y, x + r * math.cos(a), y + r * math.sin(a), col, sw)
    for k in (0.38, 0.66, 0.92):
        pts = []
        for i, a in enumerate(angs):
            rr = r * k * (0.93 if 0 < i < len(angs) - 1 else 1.0)
            pts.append((x + rr * math.cos(a), y + rr * math.sin(a)))
        s += PL(pts, col, sw)
    return '<g opacity="0.9">%s</g>' % s


def ghost(cx, top, w, h, col=None, eyes=True):
    col = col or H['bone']
    r = w / 2
    n = 3
    d = 'M%s %s V%s A%s %s 0 0 1 %s %s V%s' % (f(cx - r), f(top + h), f(top + r), f(r), f(r), f(cx + r),
                                               f(top + r), f(top + h))
    step = w / n
    for i in range(n):
        x1 = cx + r - step * i
        d += ' Q%s %s %s %s' % (f(x1 - step / 2), f(top + h - w * 0.16), f(x1 - step), f(top + h))
    s = P(d + ' Z', col)
    if eyes:
        s += E(cx - w * 0.17, top + h * 0.36, w * 0.08, w * 0.12, H['night'])
        s += E(cx + w * 0.17, top + h * 0.36, w * 0.08, w * 0.12, H['night'])
        s += E(cx, top + h * 0.58, w * 0.07, w * 0.09, H['night'])
    return s


def moon(cx, cy, r):
    return P('M%s %s A%s %s 0 1 0 %s %s A%s %s 0 1 1 %s %s Z' % (
        f(cx), f(cy - r), f(r), f(r), f(cx), f(cy + r), f(r * 0.78), f(r), f(cx), f(cy - r)), H['moon'])


def spider(cx, y0, y1, r):
    s = L(cx, y0, cx, y1 - r, H['web'], max(0.6, r * 0.18))
    for sgn in (-1, 1):
        for k, (dx, dy) in enumerate(((1.6, -0.9), (1.9, -0.1), (1.8, 0.7), (1.4, 1.4))):
            s += PL([(cx, y1), (cx + sgn * r * dx * 0.7, y1 + r * (dy - 0.6)), (cx + sgn * r * dx, y1 + r * dy)],
                    H['bat'], max(0.6, r * 0.22))
    s += E(cx, y1, r * 0.8, r, H['bat']) + Cc(cx, y1 - r * 0.9, r * 0.55, H['bat'])
    s += Cc(cx - r * 0.22, y1 - r * 0.95, r * 0.14, H['glow']) + Cc(cx + r * 0.22, y1 - r * 0.95, r * 0.14, H['glow'])
    return s


def skull(cx, cy, w):
    s = Cc(cx, cy - w * 0.08, w * 0.42, H['bone'])
    s += R(cx - w * 0.24, cy + w * 0.12, w * 0.48, w * 0.26, H['bone'], w * 0.06)
    s += E(cx - w * 0.16, cy - w * 0.06, w * 0.11, w * 0.13, H['night'])
    s += E(cx + w * 0.16, cy - w * 0.06, w * 0.11, w * 0.13, H['night'])
    s += G([(cx - w * 0.05, cy + w * 0.14), (cx + w * 0.05, cy + w * 0.14), (cx, cy + w * 0.05)], H['night'])
    for i in (-1, 0, 1):
        s += R(cx + i * w * 0.1 - w * 0.015, cy + w * 0.24, w * 0.03, w * 0.12, H['night'])
    return s


# ------------------------------------------------------------------ overrides of shared parts
def screen(x, y, w, h, base=None, hi=None):
    s = R(x, y, w, h, H['night'])
    s += G([(x + w * 0.55, y), (x + w, y), (x + w, y + h * 0.4), (x + w * 0.8, y + h)], H['night2'])
    if w >= 18:
        s += jack_face(x + w / 2, y + h * 0.5, min(w * 0.62, h * 0.95))
    else:
        s += Cc(x + w / 2, y + h / 2, min(w, h) * 0.22, H['glow'])
    return s


def zlogo(x, y, s, bg=None, fg=None):
    bg = bg or H['pumpkin']
    fg = fg or H['night']
    pts = [(0.2, 0.2), (0.8, 0.2), (0.8, 0.34), (0.4, 0.66), (0.8, 0.66), (0.8, 0.8), (0.2, 0.8), (0.2, 0.66),
           (0.6, 0.34), (0.2, 0.34)]
    return R(x, y, s, s, bg, s * 0.12) + G([(x + a * s, y + b * s) for a, b in pts], fg)


def hz_arrow(x1, x2, y, shaft, head_len, head_w, col):
    """Horizontal flat arrow from x1 to x2 (tip at x2); polygon recorded for the spacing check."""
    sg = 1 if x2 > x1 else -1
    hb = x2 - sg * head_len
    pts = [(x1, y - shaft / 2), (hb, y - shaft / 2), (hb, y - head_w / 2), (x2, y), (hb, y + head_w / 2),
           (hb, y + shaft / 2), (x1, y + shaft / 2)]
    s0, tx, ty = _XF[-1]
    ARROWS.append([(tx + px * s0, ty + py * s0) for px, py in pts])
    return G(pts, col)


def cylinder(cx, top_cy, rx, ry, h, top, body, arrows=True):
    """Pumpkin-styled router cylinder; arrows in two rows so they never touch."""
    s = E(cx, top_cy + h, rx, ry, H['pumpkin_d'])
    s += R(cx - rx, top_cy, 2 * rx, h, H['pumpkin_d'])
    # ribs on the side
    if not lo():
        for k in (-0.62, -0.22, 0.22, 0.62):
            x0 = cx + k * rx
            s += P('M%s %s Q%s %s %s %s' % (f(x0), f(top_cy + ry * math.sqrt(1 - k * k) * 0.95), f(x0 + k * 6),
                                           f(top_cy + h * 0.6 + ry * 0.5), f(x0), f(top_cy + h + ry * math.sqrt(1 - k * k)
                                                                                    * 0.95)),
                   'none', 'stroke="%s" stroke-width="2" opacity="0.45"' % H['night'])
    s += E(cx, top_cy, rx, ry, H['pumpkin'])
    if arrows:
        col = H['night']
        if lo() and _XF[-1][0] < 0.6:
            pass  # embedded and tiny: plain pumpkin cylinder
        elif lo() or _XF[-1][0] < 0.6:
            s += hz_arrow(cx - rx * 0.2, cx - rx * 0.74, top_cy, ry * 0.26, rx * 0.2, ry * 0.62, col)
            s += hz_arrow(cx + rx * 0.2, cx + rx * 0.74, top_cy, ry * 0.26, rx * 0.2, ry * 0.62, col)
        else:
            yy = ry * 0.42
            sh, hl, hw = ry * 0.17, rx * 0.15, ry * 0.42
            s += hz_arrow(cx - rx * 0.82, cx - rx * 0.30, top_cy - yy, sh, hl, hw, col)   # in
            s += hz_arrow(cx + rx * 0.22, cx + rx * 0.76, top_cy - yy, sh, hl, hw, col)   # out
            s += hz_arrow(cx + rx * 0.82, cx + rx * 0.30, top_cy + yy, sh, hl, hw, col)   # in
            s += hz_arrow(cx - rx * 0.22, cx - rx * 0.76, top_cy + yy, sh, hl, hw, col)   # out
    return s


def T_track(body_fn, tx, ty, k):
    s0, x0, y0 = _XF[-1]
    _XF.append((s0 * k, x0 + tx * s0, y0 + ty * s0))
    _, _, body = body_fn()
    _XF.pop()
    return T(body, tx, ty, k)


B.screen = screen
B.zlogo = zlogo
B.cylinder = cylinder


# ------------------------------------------------------------------ icon overrides
def cloud():
    def shape(dy, fill):
        return ''.join([
            Cc(36, 40 + dy, 22, fill), Cc(62, 29 + dy, 25, fill), Cc(91, 35 + dy, 21, fill), Cc(107, 47 + dy, 15, fill),
            R(14, 38 + dy, 108, 24, fill, 12)])
    s = shape(4, '#55437A') + shape(0, '#7C68A3')
    s += E(54, 38, 5, 6.5, H['glow_l']) + E(74, 38, 5, 6.5, H['glow_l'])
    s += E(55, 39, 2, 3, H['night']) + E(75, 39, 2, 3, H['night'])
    if not lo():
        s += P('M58 50 Q64 55 70 50', 'none', 'stroke="%s" stroke-width="2.4" stroke-linecap="round"' % H['night'])
        s += bat(110, 14, 28) + bat(17, 15, 22)
    return 128, 68, s


def firewall():
    s = B.flame(30, 44, 30, 40, H['slime'], H['slime_l'])
    s += B.flame(64, 44, 40, 44, H['slime'], H['slime_l'])
    s += B.flame(98, 44, 30, 36, H['slime'], H['slime_l'])
    x0, y0, w, h = 6, 34, 116, 60
    s += R(x0, y0, w, h, '#2A1C3D', 4)
    rows = 5
    bh = h / rows
    for r in range(rows):
        off = 0 if r % 2 == 0 else -14
        x = x0 + off
        i = 0
        while x < x0 + w:
            xa, xb = max(x, x0), min(x + 28, x0 + w)
            if xb - xa > 3:
                col = '#6B4C8A' if (i + r) % 3 else '#584075'
                s += R(xa + 1.2, y0 + r * bh + 1.2, xb - xa - 2.4, bh - 2.4, col, 1.5)
            x += 28
            i += 1
    if not lo():
        s += skull(64, 66, 20)
    return 128, 96, s


def house():
    s = ''
    if not lo():
        s += moon(104, 17, 11)
    s += R(80, 14, 13, 30, H['night'], 1.5) + R(78, 12, 17, 6, B.C['ink'], 1.5)
    s += R(16, 54, 85, 70, B.C['slate_m'])
    s += R(16, 112, 85, 12, B.C['slate'])
    s += G([(58.5, 4), (115, 58), (105, 62), (58.5, 18), (12, 62), (2, 58)], B.C['ink'])
    s += G([(58.5, 18), (105, 62), (12, 62)], B.C['slate_m'])
    s += R(44, 80, 24, 44, B.C['ink'], 2) + Cc(63, 104, 2, H['glow'])
    for wx, wy, ww in ((76, 72, 18), (24, 72, 14)):
        s += R(wx, wy, ww, 18, H['glow'], 2) + R(wx + ww / 2 - 1, wy, 2, 18, B.C['ink']) + R(wx, wy + 8, ww, 2, B.C['ink'])
    s += Cc(58.5, 40, 6, H['glow']) + R(57.5, 34, 2, 12, B.C['ink']) + R(52.5, 39, 12, 2, B.C['ink'])
    if not lo():
        s += bat(24, 22, 22)
        s += web(17, 55, 16, 0)
    return 117, 128, s


def hub():
    _, _, s = _base['hub']()
    if not lo():
        s += web(8.5, 38.5, 18, 0, '#7C68A3')
    return 128, 80, s


def switch():
    _, _, s = _base['switch']()
    if not lo():
        s += web(121.5, 38.5, 16, 1)
    return 128, 80, s


def router():
    _, _, s = _base['router']()
    if not lo():
        s += bat(64, 18, 30)
    return 128, 118, s


def crypto_router():
    _, _, s = _base['crypto_router']()
    if not lo():
        s += web(8.5, 76.5, 16, 0)
    return 128, 121, s


def modem():
    _, _, s = _base['modem']()
    if not lo():
        s += bat(104, 9, 22)
    return 128, 77, s


def network():
    pts = [(64, 20), (24, 72), (104, 72)]
    s = PL([pts[0], pts[1], pts[2], pts[0]], H['web'], 3)
    if not lo():
        s += PL([(64, 20), (64, 58)], H['web'], 1.5) + PL([(24, 72), (64, 58), (104, 72)], H['web'], 1.5)
        s += spider(64, 50, 58, 4)
    s += B.monitor(42, 2, 44, 30) + B.monitor(2, 56, 44, 30) + B.monitor(82, 56, 44, 30)
    return 128, 102, s


def network_adapter():
    _, _, s = _base['network_adapter']()
    if not lo():
        s += skull(70, 58, 16)
    return 113, 128, s


def phone(dx=0, dy=0):
    _, _, s = _base['phone']()
    if not lo():
        s += spider(65, 24, 46, 4)
    return 128, 93, s


def pbx():
    _, _, s = _base['pbx']()
    if not lo():
        s += web(6, 6, 16, 0, '#7C68A3')
    return 128, 125, s


def ip_pbx():
    _, _, s = _base['ip_pbx']()
    if not lo():
        s += web(6, 6, 14, 0, '#7C68A3')
    return 128, 119, s


def ip_pbx_symbol():
    s = B.tower(4, 4, 44, 112, B.C['g2'], B.C['g4'], bays=4, button=B.C['green'])
    s += T_track(router_symbol, 64, 4, 0.46)
    _, _, ph = _base['phone']()
    s += T(ph, 42, 58, 0.66)
    if not lo():
        s += web(6, 6, 14, 0, '#7C68A3')
    return 128, 119, s


def printer():
    _, _, s = _base['printer']()
    s += G([(28, 85), (100, 85), (103.5, 114), (24.5, 114)], B.C['white'])
    s += bat(64, 98, 34) if not lo() else Cc(64, 99, 6, H['bat'])
    return 128, 119, s


def _rack_colors(s):
    return s.replace('#45545D', '#2E1D45').replace('#3E4C55', '#3B2650')


def rack_42():
    _, _, s = _base['rack_42']()
    s = _rack_colors(s)
    if not lo():
        s += web(15, 25, 26, 0) + web(119, 25, 26, 1)
        s += spider(100, 25, 120, 4)
    return 134, 435, s


def rack_42_with_door():
    s = _rack_colors(B.rack_body(0, 2, 134, 420))
    if not lo():
        s += web(15, 27, 26, 0)
        s += ghost(126, 150, 38, 50)
    s += G([(131, 6), (197, 0), (197, 440), (131, 424)], B.C['slate'])
    s += G([(138, 18), (190, 12), (190, 428), (138, 412)], '#7E6AA6', 'opacity="0.75"')
    s += G([(138, 18), (190, 12), (190, 60), (138, 150)], B.C['white'], 'opacity="0.25"')
    s += G([(183, 190), (190, 189), (190, 230), (183, 230)], H['glow'])
    if not lo():
        s += web(189, 14, 24, 1)
    return 199, 440, s


def satellite():
    _, _, s = _base['satellite']()
    if not lo():
        s = moon(14, 12, 9) + s
    return 128, 78, s


def satellite_antenna():
    _, _, s = _base['satellite_antenna']()
    if not lo():
        s += bat(76, 14, 22)
    return 92, 128, s


def server():
    s = B.tower(8, 4, 66, 120, bays=3)
    x, y, w, h = 8, 4, 66, 120
    s += R(x + w * 0.12, y + h * 0.47, w * 0.76, h * 0.27, B.C['slate'])
    s += jack_face(x + w / 2, y + h * 0.6, w * 0.62)
    return 96, 128, s


def ups():
    x, y, w, h = 10, 4, 79, 120
    out = [(x + w * 0.26, y), (x + w * 0.74, y), (x + w, y + h * 0.22), (x + w * 0.8, y + h), (x + w * 0.2, y + h),
           (x, y + h * 0.22)]
    inner = [(x + w * 0.3, y + 6), (x + w * 0.7, y + 6), (x + w - 7, y + h * 0.23), (x + w * 0.77, y + h - 6),
             (x + w * 0.23, y + h - 6), (x + 7, y + h * 0.23)]
    s = G(out, H['wood']) + G(inner, H['wood_l'])
    gx, gw, gy = x + w * 0.27, w * 0.46, y + h * 0.16
    s += R(gx, gy, gw, 14, H['night'], 2) + R(gx + gw, gy + 4, 3, 6, H['night'])
    for i in range(4):
        s += R(gx + 2 + i * (gw - 4) / 4 + 0.5, gy + 2.5, (gw - 4) / 4 - 1, 9, H['slime'], 0.8)
    cx = x + w / 2
    s += R(cx - 2.5, y + h * 0.36, 5, 34, H['bone'], 1) + R(cx - 11, y + h * 0.36 + 9, 22, 5, H['bone'], 1)
    cy = y + h * 0.78
    s += Cc(cx, cy, 9, B.C['red'])
    s += P('M%s %s A5 5 0 1 0 %s %s' % (f(cx - 3.4), f(cy - 3.6), f(cx + 3.4), f(cy - 3.6)), 'none',
           'stroke="%s" stroke-width="2" stroke-linecap="round"' % B.C['white'])
    s += L(cx, cy - 6.5, cx, cy - 1, B.C['white'], 2)
    return 99, 128, s


def video_terminal():
    tiles = ''
    for i in range(4):
        tx = 13 + (i % 2) * 44
        ty = 23 + (i // 2) * 28.5
        tiles += R(tx, ty, 42, 27.5, H['night'] if i % 3 == 0 else H['night2'], 1.5)
        cx, cy = tx + 21, ty + 14
        if i == 0:
            tiles += ghost(cx, ty + 3, 16, 22)
        elif i == 1:
            tiles += pumpkin(cx, cy + 1, 22)
        elif i == 2:
            tiles += skull(cx, cy, 20)
        else:
            tiles += moon(cx - 6, cy - 2, 7) + bat(cx + 5, cy + 3, 22, H['bone'])
    content = R(12, 22, 88, 58, H['night'])
    content += '<clipPath id="vt"><rect x="12" y="22" width="88" height="58"/></clipPath><g clip-path="url(#vt)">' \
               + tiles + '</g>'
    s = B.monitor(6, 16, 100, 70, content=content)
    s += R(50, 6, 12, 12, B.C['slate'], 6) + Cc(56, 12, 3.5, H['glow']) + R(54, 16, 4, 3, B.C['slate'])
    s += P('M84 112 A18 18 0 0 1 120 112', 'none', 'stroke="%s" stroke-width="4" stroke-linecap="round"' % B.C['slate'])
    s += R(78, 106, 12, 18, B.C['slate'], 5) + R(114, 106, 9, 18, B.C['slate'], 4)
    s += P('M86 122 Q 92 128 104 124', 'none', 'stroke="%s" stroke-width="2.5" stroke-linecap="round"' % B.C['slate_l'])
    s += Cc(105, 124, 2.5, H['glow'])
    return 123, 128, s


def workstation():
    _, _, s = _base['workstation']()
    if not lo():
        s += web(95, 14, 14, 0, '#7C68A3')
    return 128, 117, s


def router_symbol():
    return 128, 73, cylinder(64, 25, 58, 21, 22, None, None)


def crypto_router_symbol():
    s = B.padlock(64, 3, 34)
    s += cylinder(64, 79, 58, 21, 22, None, None)
    return 128, 127, s


_base = {n: getattr(B, n) for n in ('hub', 'switch', 'router', 'crypto_router', 'modem', 'network_adapter', 'phone',
                                    'pbx', 'ip_pbx', 'printer', 'rack_42', 'satellite', 'satellite_antenna',
                                    'workstation')}

# make composite base icons (PBX, IP PBX) pick up the Halloween phone/router
B.phone = phone
B.router = router
B.router_symbol = router_symbol
_base['phone'] = _base['phone']

OVERRIDES = {
    'Cloud': cloud, 'Firewall': firewall, 'House': house, 'Hub': hub, 'Switch': switch, 'Router': router,
    'Crypto-router': crypto_router, 'Modem': modem, 'Network': network, 'Network_adapter': network_adapter,
    'Phone': phone, 'PBX': pbx, 'IP_PBX': ip_pbx, 'IP_PBX_symbol': ip_pbx_symbol, 'Printer': printer,
    'Satellite': satellite, 'Satellite_antenna': satellite_antenna, 'Server': server, 'UPS': ups,
    'Video_terminal': video_terminal, 'Workstation': workstation, 'Router_symbol': router_symbol,
    'Crypto-router_symbol': crypto_router_symbol,
}
B.MODERN.update(OVERRIDES)
B.RACKS.update({'Rack_42': rack_42, 'Rack_42_with_door': rack_42_with_door})
MODERN, RACKS, CLASSIC = B.MODERN, B.RACKS, B.CLASSIC


def icon_svg(name, lo_=False):
    del ARROWS[:]
    return B.icon_svg(name, lo_)


def classic_svg(name, lo_=False):
    del ARROWS[:]
    return B.classic_svg(name, lo_)


def check_arrows(name, lo_, min_gap=2.0):
    """Smallest distance between any two arrows of an icon (icon units) and arrow count."""
    from shapely.geometry import Polygon
    icon_svg(name, lo_)
    polys = [Polygon(p) for p in ARROWS]
    worst = float('inf')
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            worst = min(worst, polys[i].distance(polys[j]))
    return worst, len(polys)
