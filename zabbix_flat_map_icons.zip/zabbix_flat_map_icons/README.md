# Zabbix map icons — flat redesign

These files are a drop-in replacement for `misc/images/` and `database/*/images.sql` in the Zabbix source tree (8.0.0rc3).

- **Style:** flat filled. It uses the Zabbix brand palette: red `#D40000`, blue `#0275B8`, and slate and gray neutrals.
- **Names, pixel sizes and image IDs:** identical to the originals, so existing maps keep working.
- **Small icons:** files at 32 px and below are drawn with less detail so they stay readable.

## Contents

| Path | What |
|---|---|
| `svg/elements/` | 41 vector sources, one per icon type |
| `svg/equipment_rack/` | `Rack_42.svg`, `Rack_42_with_door.svg` |
| `svg/classic/` | 10 vector sources for the classic set (square canvas) |
| `png_modern/` | 187 PNGs, same file names and dimensions as the originals |
| `png_classic/` | 20 PNGs (`X.png` 48×48, `X_small.png` 24×24) |
| `database/mysql/images.sql`<br>`database/postgresql/images.sql` | For new installs. Same format and `imageid` order as `png_to_sql.sh` output |
| `database/*/update_images.sql` | For existing installs. Swaps the image data, matching on the built-in icon names |
| `preview_*.png` | Preview sheets |
| `tools/` | Python generator: `icons.py` holds the drawings, `render.py` makes the PNGs, `gen_sql.py` makes the SQL. Needs `cairosvg` and Pillow |

## Applying

**New install:** replace `database/mysql/images.sql` and `database/postgresql/images.sql` in the source tree. Then build and import them as usual.

**Existing install:**

1. Back up the `images` table.
2. Run the script for your database:
   - MySQL: `mysql zabbix < database/mysql/update_images.sql`
   - PostgreSQL: `psql zabbix -f database/postgresql/update_images.sql`

The update script only changes rows whose names match the built-in icons. Custom images are left as they are.

**Rack scale:** inside `Rack_42`, 42 units of the 128-px rack-mountable icons fit exactly over the mounting posts. One unit is 9 px.
